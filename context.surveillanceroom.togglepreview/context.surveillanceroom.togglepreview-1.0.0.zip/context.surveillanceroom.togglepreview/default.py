import xbmc

if __name__ == "__main__":
    # Toggle Preview
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.surveillanceroom?action=toggle_preview)')
